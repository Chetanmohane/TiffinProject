"use client";

export default function NotificationsPage() {
  return (
    <div className="max-w-4xl space-y-6">

      <h2 className="text-2xl font-bold">Alerts & Notifications</h2>

      <div className="space-y-4">
        <Alert text="Tomorrow is a holiday. No delivery." />
        <Alert text="Subscription renewal in 3 days." />
      </div>

    </div>
  );
}

const Alert = ({ text }: any) => (
  <div className="bg-white p-4 rounded-xl shadow border-l-4 border-orange-500">
    {text}
  </div>
);
