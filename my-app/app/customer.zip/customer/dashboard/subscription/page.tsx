"use client";

export default function SubscriptionPage() {
  return (
    <div className="max-w-4xl space-y-6">

      <h2 className="text-2xl font-bold">My Subscription</h2>

      <div className="bg-white p-6 rounded-xl shadow">
        <p><b>Plan:</b> Standard Full</p>
        <p><b>Status:</b> Active</p>
        <p><b>Price:</b> ₹3500 / month</p>

        <div className="mt-6 flex flex-wrap gap-4">
          <button className="px-6 py-2 bg-red-500 text-white rounded-lg">
            Pause Subscription
          </button>
          <button className="px-6 py-2 bg-green-500 text-white rounded-lg">
            Resume
          </button>
        </div>
      </div>

    </div>
  );
}
