"use client";

export default function MenuPage() {
  return (
    <div className="max-w-5xl space-y-6">

      <h2 className="text-2xl font-bold">Today's Menu 🍽️</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <MenuCard time="Lunch" items="Roti, Dal, Aloo Sabzi, Rice" />
        <MenuCard time="Dinner" items="Chapati, Paneer, Salad" />
      </div>

    </div>
  );
}

const MenuCard = ({ time, items }: any) => (
  <div className="bg-white p-5 rounded-xl shadow">
    <h3 className="text-lg font-semibold">{time}</h3>
    <p className="text-gray-600 mt-2">{items}</p>
  </div>
);
