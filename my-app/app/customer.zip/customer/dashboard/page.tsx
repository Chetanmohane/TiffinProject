"use client";

export default function CustomerDashboard() {
  return (
    <div className="space-y-8">

      <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
        Welcome Back 👋
      </h1>

      {/* STATS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card title="Subscription" value="Active" />
        <Card title="Today's Meal" value="Roti, Dal, Sabzi" />
        <Card title="Delivery Status" value="Out for Delivery" />
        <Card title="Next Renewal" value="25 Jan 2026" />
      </div>

      {/* QUICK ACTIONS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Action label="Manage Plan" link="/customer/subscription" />
        <Action label="Pause Meal" link="/customer/subscription" />
        <Action label="View Menu" link="/customer/menu" />
        <Action label="Settings" link="/customer/settings" />
      </div>

    </div>
  );
}

const Card = ({ title, value }: any) => (
  <div className="bg-white p-5 rounded-xl shadow-sm">
    <p className="text-gray-500 text-sm">{title}</p>
    <h3 className="text-xl font-bold mt-1">{value}</h3>
  </div>
);

const Action = ({ label, link }: any) => (
  <a
    href={link}
    className="bg-orange-500 text-white py-3 rounded-lg text-center hover:bg-orange-600 transition"
  >
    {label}
  </a>
);
