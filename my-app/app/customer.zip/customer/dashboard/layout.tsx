"use client";

import Link from "next/link";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">

      {/* SIDEBAR */}
      <aside className="w-full md:w-64 bg-gray-900 text-white p-5">
        <h2 className="text-xl font-bold mb-6">Customer Panel</h2>

        <nav className="space-y-4">
          <Link href="/customer/dashboard" className="block hover:text-orange-400">
            Dashboard
          </Link>
          <Link href="/customer/subscription" className="block hover:text-orange-400">
            Subscription
          </Link>
          <Link href="/customer/menu" className="block hover:text-orange-400">
            Menu
          </Link>
          <Link href="/customer/settings" className="block hover:text-orange-400">
            Settings
          </Link>
          <Link href="/customer/notifications" className="block hover:text-orange-400">
            Alerts
          </Link>
        </nav>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 p-4 sm:p-6">{children}</main>
    </div>
  );
}
