"use client";

export default function SettingsPage() {
  return (
    <div className="max-w-3xl space-y-8">

      <h2 className="text-2xl font-bold">Account Settings</h2>

      {/* PROFILE */}
      <section className="bg-white p-6 rounded-xl shadow space-y-4">
        <input placeholder="Full Name" className="input" />
        <input placeholder="Mobile Number" className="input" />
        <textarea placeholder="Address" className="input" />
      </section>

      {/* PASSWORD */}
      <section className="bg-white p-6 rounded-xl shadow space-y-4">
        <input type="password" placeholder="Current Password" className="input" />
        <input type="password" placeholder="New Password" className="input" />
      </section>

      <button className="bg-orange-500 text-white px-6 py-3 rounded-lg">
        Save Changes
      </button>

    </div>
  );
}
